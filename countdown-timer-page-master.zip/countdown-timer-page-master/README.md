# countdown-timer-page

A simple counter counting down time.

 - [Preview timer](https://jakubgania.github.io/countdown-timer-page/timer)
